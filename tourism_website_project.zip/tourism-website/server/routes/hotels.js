const express = require('express');
const router = express.Router();

const hotels = [
  { id: 1, name: 'Hotel Taj', location: 'Mumbai' },
  { id: 2, name: 'The Oberoi', location: 'Delhi' },
  { id: 3, name: 'ITC Maurya', location: 'Bangalore' },
];

router.get('/', (req, res) => {
  res.json(hotels);
});

module.exports = router;

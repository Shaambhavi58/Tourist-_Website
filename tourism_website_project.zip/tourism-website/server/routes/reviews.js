const express = require('express');
const router = express.Router();

const reviews = [
  { id: 1, user: 'John', comment: 'Amazing experience!' },
  { id: 2, user: 'Jane', comment: 'Loved the hospitality!' },
];

router.get('/', (req, res) => {
  res.json(reviews);
});

module.exports = router;

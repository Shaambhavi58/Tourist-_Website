import React from 'react';
import Home from './components/Home';
import Hotels from './components/Hotels';
import Reviews from './components/Reviews';
import Weather from './components/Weather';

const App = () => {
  return (
    <div>
      <Home />
      <Weather />
      <Hotels />
      <Reviews />
    </div>
  );
};

export default App;

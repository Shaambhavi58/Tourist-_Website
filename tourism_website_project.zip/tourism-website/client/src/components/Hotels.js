import React, { useState, useEffect } from 'react';

const Hotels = () => {
  const [hotels, setHotels] = useState([]);

  useEffect(() => {
    fetch('/api/hotels')
      .then(res => res.json())
      .then(data => setHotels(data));
  }, []);

  return (
    <div>
      <h2>Hotels</h2>
      <ul>
        {hotels.map(hotel => (
          <li key={hotel.id}>{hotel.name} - {hotel.location}</li>
        ))}
      </ul>
    </div>
  );
};

export default Hotels;

import React, { useState, useEffect } from 'react';

const Weather = () => {
  const [weather, setWeather] = useState(null);

  useEffect(() => {
    fetch('/api/weather')
      .then(res => res.json())
      .then(data => setWeather(data));
  }, []);

  return (
    <div>
      <h2>Current Weather</h2>
      {weather ? (
        <div>
          <p>{weather.city}: {weather.temperature}°C</p>
        </div>
      ) : (
        <p>Loading weather...</p>
      )}
    </div>
  );
};

export default Weather;
